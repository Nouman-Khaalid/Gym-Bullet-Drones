# #########  modified by   Nouman K  version 2  ########################
# #########    Nouman K  version 2  ########################
# #########    Nouman K  version 2  ########################


# import numpy as np
# import pybullet as p
# import gymnasium as gym
# from gym import spaces
# from gym_pybullet_drones.envs.BaseRLAviary import BaseRLAviary
# from gym_pybullet_drones.utils.enums import DroneModel, Physics  # Add this import
# from gym_pybullet_drones.utils.utils import Battery

# class SingletonPyBullet:
#     _instance = None

#     def __new__(cls, gui=True):
#         if cls._instance is None:
#             cls._instance = super(SingletonPyBullet, cls).__new__(cls)
#             cls._instance.client = p.connect(p.GUI if gui else p.DIRECT)
#         return cls._instance

# class CustomObjectPickupAviary(BaseRLAviary):
#     MASS = 0.5
#     max_distance = 0.32

#     def __init__(self, gui=True, drone_model=DroneModel.CF2X, num_drones=1, physics=Physics.PYB, neighbourhood_radius=float('inf'), freq=240, aggregate_phy_steps=1, record=False, obstacles=False, user_debug_gui=True, vision_attributes=False, dynamics_attributes=False):
#         self.gui = gui
#         self.pybullet_instance = SingletonPyBullet(gui)
#         self.CLIENT = self.pybullet_instance.client
#         super().__init__(drone_model=drone_model, num_drones=num_drones, physics=physics, neighbourhood_radius=neighbourhood_radius, freq=freq, aggregate_phy_steps=aggregate_phy_steps, gui=gui, record=record, obstacles=obstacles, user_debug_gui=user_debug_gui, vision_attributes=vision_attributes, dynamics_attributes=dynamics_attributes)
#         self.object_ids = []
#         self.object_size_threshold = 0.1
#         self.target_object_size = 0.05
#         self.object_positions = []
#         self.battery = Battery(initial_level=1.0, max_level=1.0, min_level=0.0, discharge_rate=0.01)
#         self.previous_distance_to_object = 0.0
#         self.EPISODE_LEN_SEC = 5
#         self.target_pos = self._generate_random_target_position()
#         self.target_vel = self._generate_random_target_velocity()

#         self.observation_space = gym.spaces.Box(low=-2.0, high=2.0, shape=(4,), dtype=np.float32)
#         self.action_space = gym.spaces.Box(low=-1.0, high=1.0, shape=(4,), dtype=np.float32)

#     def _generate_random_target_position(self):
#         x_range = (-5, 5)
#         y_range = (-5, 5)
#         z_range = (0, 1)

#         target_pos = np.array([
#             np.random.uniform(*x_range),
#             np.random.uniform(*y_range),
#             np.random.uniform(*z_range)
#         ])
#         return target_pos

#     def _generate_random_target_velocity(self):
#         velocity_range = (-1, 1)
#         target_vel = np.random.uniform(*velocity_range, size=(3,))
#         return target_vel

#     def _get_obs(self):
#         pos, orn = self._getDroneStateVector(0)[:3], self._getDroneStateVector(0)[3:7]
#         vel = self._getDroneStateVector(0)[10:13]
#         target_pos = self.target_pos
#         distance_to_target = np.linalg.norm(target_pos - pos)
#         self.previous_distance_to_object = distance_to_target

#         obs = np.concatenate([pos, target_pos, vel])
#         return obs

#     def _compute_reward(self):
#         reward = 0
#         distance_to_object = self.previous_distance_to_object
#         reward -= distance_to_object
#         return reward

#     def _compute_done(self):
#         return False

#     def _compute_info(self):
#         info = {}

#         drone_states = []
#         for drone_index in range(len(self.DRONE_IDS)):
#             drone_state = self._getDroneState(drone_index)
#             drone_states.append(drone_state)

#         info['drone_states'] = drone_states
#         return info

#     def make_env(env_id, rank, seed=0):
#         def _init():
#             env = gym.make(env_id)
#             env.seed(seed + rank)
#             return env
#         return _init

#     def _checkObjectPickup(self, action):
#         drone_position = self._getDroneStateVector(0)[:3]
#         for obj_id, obj_pos in zip(self.object_ids, self.object_positions):
#             distance_to_object = np.linalg.norm(np.array(obj_pos) - drone_position)
#             if distance_to_object < 0.1:
#                 size = p.getVisualShapeData(obj_id, physicsClientId=self.CLIENT)[0][3][0]
#                 if size <= self.target_object_size:
#                     p.removeBody(obj_id, physicsClientId=self.CLIENT)
#                     self.object_ids.remove(obj_id)
#                     self.object_positions.remove(obj_pos)
#                     self._add_objects()

#                     rpm_scaling_factor = 0.25
#                     max_rpm = 9.81 * self.MASS / 4
#                     current_rpm = action * max_rpm
#                     p.applyExternalForce(self.DRONE_IDS[0], -1, forceObj=[0, 0, sum(current_rpm)], 
#                                     posObj=drone_position, flags=p.WORLD_FRAME, physicsClientId=self.CLIENT)

#                     return True
#                 else:
#                     return False
#         return False



import sys
import os

# Ensure the project directory is in the Python path
project_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
sys.path.insert(0, project_dir)

import numpy as np
import pybullet as p
import gymnasium as gym
from gym import spaces
from gym_pybullet_drones.envs.BaseRLAviary import BaseRLAviary
from gym_pybullet_drones.utils.enums import DroneModel, Physics
from gym_pybullet_drones.utils.utils import Battery

class SingletonPyBullet:
    _instance = None

    def __new__(cls, gui=True):
        if cls._instance is None:
            cls._instance = super(SingletonPyBullet, cls).__new__(cls)
            cls._instance.client = p.connect(p.GUI if gui else p.DIRECT)
        return cls._instance

class CustomObjectPickupAviary(BaseRLAviary):
    MASS = 0.5
    max_distance = 0.32

    def __init__(self, gui=True, drone_model=DroneModel.CF2X, num_drones=1, physics=Physics.PYB, neighbourhood_radius=float('inf'), freq=240, aggregate_phy_steps=1, record=False, obstacles=False, user_debug_gui=True, vision_attributes=False, dynamics_attributes=False, initial_xyzs=None, initial_rpys=None, initial_vels=None, initial_angvels=None, obs=None, act=None):
        self.gui = gui
        self.pybullet_instance = SingletonPyBullet(gui)
        self.CLIENT = self.pybullet_instance.client
        super().__init__(drone_model=drone_model, num_drones=num_drones, physics=physics, neighbourhood_radius=neighbourhood_radius, freq=freq, aggregate_phy_steps=aggregate_phy_steps, gui=gui, record=record, obstacles=obstacles, user_debug_gui=user_debug_gui, vision_attributes=vision_attributes, dynamics_attributes=dynamics_attributes, initial_xyzs=initial_xyzs, initial_rpys=initial_rpys, initial_vels=initial_vels, initial_angvels=initial_angvels, obs=obs, act=act)
        self.object_ids = []
        self.object_size_threshold = 0.1
        self.target_object_size = 0.05
        self.object_positions = []
        self.battery = Battery(initial_level=1.0, max_level=1.0, min_level=0.0, discharge_rate=0.01)
        self.previous_distance_to_object = 0.0
        self.EPISODE_LEN_SEC = 5
        self.target_pos = self._generate_random_target_position()
        self.target_vel = self._generate_random_target_velocity()

        self.observation_space = gym.spaces.Box(low=-2.0, high=2.0, shape=(4,), dtype=np.float32)
        self.action_space = gym.spaces.Box(low=-1.0, high=1.0, shape=(4,), dtype=np.float32)

    def _generate_random_target_position(self):
        x_range = (-5, 5)
        y_range = (-5, 5)
        z_range = (0, 1)

        target_pos = np.array([
            np.random.uniform(*x_range),
            np.random.uniform(*y_range),
            np.random.uniform(*z_range)
        ])
        return target_pos

    def _generate_random_target_velocity(self):
        velocity_range = (-1, 1)
        target_vel = np.random.uniform(*velocity_range, size=(3,))
        return target_vel

    def _get_obs(self):
        pos, orn = self._getDroneStateVector(0)[:3], self._getDroneStateVector(0)[3:7]
        vel = self._getDroneStateVector(0)[10:13]
        target_pos = self.target_pos
        distance_to_target = np.linalg.norm(target_pos - pos)
        self.previous_distance_to_object = distance_to_target

        obs = np.concatenate([pos, target_pos, vel])
        return obs

    def _compute_reward(self):
        reward = 0
        distance_to_object = self.previous_distance_to_object
        reward -= distance_to_object
        return reward

    def _compute_done(self):
        return False

    def _compute_info(self):
        info = {}

        drone_states = []
        for drone_index in range(len(self.DRONE_IDS)):
            drone_state = self._getDroneState(drone_index)
            drone_states.append(drone_state)

        info['drone_states'] = drone_states
        return info

    def make_env(env_id, rank, seed=0):
        def _init():
            env = gym.make(env_id)
            env.seed(seed + rank)
            return env
        return _init

    def _checkObjectPickup(self, action):
        drone_position = self._getDroneStateVector(0)[:3]
        for obj_id, obj_pos in zip(self.object_ids, self.object_positions):
            distance_to_object = np.linalg.norm(np.array(obj_pos) - drone_position)
            if distance_to_object < 0.1:
                size = p.getVisualShapeData(obj_id, physicsClientId=self.CLIENT)[0][3][0]
                if size <= self.target_object_size:
                    p.removeBody(obj_id, physicsClientId=self.CLIENT)
                    self.object_ids.remove(obj_id)
                    self.object_positions.remove(obj_pos)
                    self._add_objects()

                    rpm_scaling_factor = 0.25
                    max_rpm = 9.81 * self.MASS / 4
                    current_rpm = action * max_rpm
                    p.applyExternalForce(self.DRONE_IDS[0], -1, forceObj=[0, 0, sum(current_rpm)], 
                                    posObj=drone_position, flags=p.WORLD_FRAME, physicsClientId=self.CLIENT)

                    return True
                else:
                    return False
        return False
