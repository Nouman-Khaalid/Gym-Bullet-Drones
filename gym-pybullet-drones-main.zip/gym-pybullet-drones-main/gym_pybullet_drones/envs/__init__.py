#########  modified by   Nouman K  version 2  ########################
#########    Nouman K  version 2  ########################
#########    Nouman K  version 2  ########################



import os
import time
import numpy as np
import sys
from stable_baselines3.common.vec_env import DummyVecEnv
from stable_baselines3 import SAC
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.callbacks import CheckpointCallback, EvalCallback
from argparse import ArgumentParser
from gym.spaces import Box
sys.path.append(os.path.abspath(r'C:\\Users\\user\\Downloads\\gym-pybullet-drones-main'))
from gym_pybullet_drones.utils.utils import sync, str2bool
from gym_pybullet_drones.utils.Logger import Logger
from gym_pybullet_drones.envs.ObjectPickupAviary import CustomObjectPickupAviary
from gym_pybullet_drones.utils.enums import DroneModel, Physics, ActionType, ObservationType
from stable_baselines3.common.vec_env import VecNormalize

# --- Define and parse (optional) arguments for the script ---
parser = ArgumentParser(description="Drone RL Training and PID Control")
parser.add_argument('--gui', type=str2bool, default=True, help='Use GUI during training')
parser.add_argument('--record_video', type=str2bool, default=False, help='Record video of the training')
parser.add_argument('--plot', type=str2bool, default=False, help='Plot the results after training')
ARGS = parser.parse_args()

# --- Environment Configuration ---
env_name = "object-pickup-aviary-v0"

def make_env():
    env = CustomObjectPickupAviary(
        drone_model=DroneModel.CF2X,
        num_drones=1,
        initial_xyzs=np.array([[0, 0, 1]]),
        physics=Physics.PYB,
        act=ActionType.RPM,
        obs=ObservationType.KIN,
        gui=True,
        record=str2bool(ARGS.record_video)
    )
    return env

# Ensure the action space is Box(-1.0, 1.0, (4,), float32)
env = make_vec_env(make_env, n_envs=4)
env = VecNormalize(env, norm_obs=True, norm_reward=True, clip_obs=10.)

# --- Training Configuration ---
ALG = "SAC"
TOTAL_TIMESTEPS = 1000000
LOG_DIR = "./logs/"
MODEL_DIR = "./models/"
os.makedirs(LOG_DIR, exist_ok=True)
os.makedirs(MODEL_DIR, exist_ok=True)

# --- Model Training ---
def train_rl_model():
    checkpoint_callback = CheckpointCallback(save_freq=10000, save_path=MODEL_DIR, name_prefix=ALG)
    eval_callback = EvalCallback(env, best_model_save_path=MODEL_DIR, log_path=LOG_DIR, eval_freq=5000, deterministic=True, render=False)
    model = SAC("MlpPolicy", env, verbose=1, tensorboard_log=LOG_DIR)
    model.learn(total_timesteps=TOTAL_TIMESTEPS, callback=[checkpoint_callback, eval_callback])
    model.save(f"{MODEL_DIR}/{ALG}_final")

# --- Run PID Control ---
def run_pid_control():
    env.reset()
    logger = Logger(logging_freq_hz=int(env.get_attr('CTRL_FREQ')[0]), num_drones=1)
    PID_COEFFS = {"P": {"x": 0.4, "y": 0.4, "z": 1.25}, "I": {"x": 0.05, "y": 0.05, "z": 0.05}, "D": {"x": 0.2, "y": 0.2, "z": 0.5}}
    PID_COEFFS_YAW = {"P": 0.1, "I": 0.0, "D": 0.3}

    integral = np.zeros(3)
    integral_yaw = 0.0
    prev_error = np.zeros(3)
    prev_yaw_error = 0.0

    start = time.time()
    for i in range(6 * env.get_attr('CTRL_FREQ')[0]):
        state = env.get_attr('GET_OBS')[0][0]
        target_yaw = 0.0
        action = np.zeros(4)

        closest_objects = env.get_attr('ClosestObjects')[0]
        target_pos = closest_objects[0] if not env.get_attr('carrying_object')[0] else env.get_attr('drop_off_zone')[0]

        for j, axis in enumerate(["x", "y", "z"]):
            error = target_pos[j] - state[j]
            integral[j] += PID_COEFFS[axis]["I"] * error * env.get_attr('TIMESTEP')[0]
            derivative = PID_COEFFS[axis]["D"] * (error - prev_error[j]) / env.get_attr('TIMESTEP')[0]
            action[j] = PID_COEFFS[axis]["P"] * error + integral[j] + derivative
            prev_error[j] = error

        current_yaw = state[9]
        yaw_error = (target_yaw - current_yaw + np.pi) % (2 * np.pi) - np.pi
        integral_yaw += yaw_error * env.get_attr('TIMESTEP')[0]
        derivative = PID_COEFFS_YAW["D"] * (yaw_error - prev_yaw_error) / env.get_attr('TIMESTEP')[0]
        action[3] = PID_COEFFS_YAW["P"] * yaw_error + PID_COEFFS_YAW["I"] * integral_yaw + derivative
        prev_yaw_error = yaw_error

        action[:3] = np.clip(action[:3], -1, 1)
        action[3] = np.clip(action[3], -1, 1)

        obs, reward, done, info = env.step(action)
        logger.log(drone=0, timestamp=i / env.get_attr('SIM_FREQ')[0], state=obs[0], control=np.zeros(12))

        if done:
            obs = env.reset()
        if ARGS.gui:
            sync(i, start, env.get_attr('TIMESTEP')[0])
            env.render()

    if ARGS.plot:
        logger.plot()
    logger.save_as_csv("pid")

if ALG in ['SAC']:
    train_rl_model()
elif ALG == "PID":
    run_pid_control()

if __name__ == "__main__":
    if ALG in ['SAC']:
        train_rl_model()
    elif ALG == "PID":
        run_pid_control()
