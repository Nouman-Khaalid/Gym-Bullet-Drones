#########  modified by   Nouman K  version 2  ########################
#########    Nouman K  version 2  ########################
#########    Nouman K  version 2  ########################


# import tkinter as tk
# from tkinter import messagebox
# import sys
# import os
# import pybullet as p

# # Add the directory containing gym_pybullet_drones to the Python path
# project_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), 'gym_pybullet_drones'))
# sys.path.append(project_dir)

# # Correct the import based on the provided structure
# from gym_pybullet_drones.ObjectPickAviary import ObjectPickupAviary

# # Create a custom class to override the PyBullet connection
# class CustomObjectPickupAviary(ObjectPickupAviary):
#     def __init__(self, **kwargs):
#         super().__init__(**kwargs)
#         # Override the client connection to use DIRECT mode
#         self.CLIENT = p.connect(p.DIRECT)

# # Create the main window
# root = tk.Tk()
# root.title("Drone Simulation GUI")

# # Create frames for different sections
# control_frame = tk.Frame(root)
# control_frame.pack(padx=10, pady=10)

# parameter_frame = tk.Frame(root)
# parameter_frame.pack(padx=10, pady=10)

# log_frame = tk.Frame(root)
# log_frame.pack(padx=10, pady=10)

# # Control Frame
# tk.Label(control_frame, text="Simulation Controls").grid(row=0, column=0, columnspan=2)

# def start_simulation():
#     try:
#         # Use CustomObjectPickupAviary to start the simulation
#         aviary = CustomObjectPickupAviary()
#         aviary.reset()
#         log_text.insert(tk.END, "Simulation started\n")
#     except Exception as e:
#         log_text.insert(tk.END, f"Error starting simulation: {str(e)}\n")

# def stop_simulation():
#     try:
#         # Use CustomObjectPickupAviary to stop the simulation
#         aviary = CustomObjectPickupAviary()
#         aviary.step()
#         log_text.insert(tk.END, "Simulation stopped\n")
#     except Exception as e:
#         log_text.insert(tk.END, f"Error stopping simulation: {str(e)}\n")

# start_button = tk.Button(control_frame, text="Start Simulation", command=start_simulation)
# start_button.grid(row=1, column=0, padx=5, pady=5)

# stop_button = tk.Button(control_frame, text="Stop Simulation", command=stop_simulation)
# stop_button.grid(row=1, column=1, padx=5, pady=5)

# # Parameter Frame
# tk.Label(parameter_frame, text="Simulation Parameters").grid(row=0, column=0, columnspan=2)

# tk.Label(parameter_frame, text="Parameter 1:").grid(row=1, column=0, sticky=tk.E)
# param1_entry = tk.Entry(parameter_frame)
# param1_entry.grid(row=1, column=1)

# tk.Label(parameter_frame, text="Parameter 2:").grid(row=2, column=0, sticky=tk.E)
# param2_entry = tk.Entry(parameter_frame)
# param2_entry.grid(row=2, column=1)

# # Log Frame
# tk.Label(log_frame, text="Simulation Logs").grid(row=0, column=0)
# log_text = tk.Text(log_frame, height=10, width=50)
# log_text.grid(row=1, column=0)

# # Run the application
# root.mainloop()












import tkinter as tk
from tkinter import messagebox
import sys
import os
import pybullet as p

# Add the directory containing gym_pybullet_drones to the Python path
project_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), 'gym_pybullet_drones'))
sys.path.append(project_dir)

# Correct the import based on the provided structure
from gym_pybullet_drones.envs.ObjectPickupAviary import ObjectPickupAviary

# Singleton pattern for PyBullet connection
class SingletonPyBullet:
    _instance = None

    def __new__(cls, gui=True):
        if cls._instance is None:
            cls._instance = super(SingletonPyBullet, cls).__new__(cls)
            cls._instance.client = p.connect(p.GUI if gui else p.DIRECT)
        return cls._instance

# Create a custom class to override the PyBullet connection
class CustomObjectPickupAviary(ObjectPickupAviary):
    def __init__(self, gui=True, **kwargs):
        self.pybullet_instance = SingletonPyBullet(gui)
        self.CLIENT = self.pybullet_instance.client
        super().__init__(gui=gui, **kwargs)

# Create the main window
root = tk.Tk()
root.title("Drone Simulation GUI")

# Create frames for different sections
control_frame = tk.Frame(root)
control_frame.pack(padx=10, pady=10)

parameter_frame = tk.Frame(root)
parameter_frame.pack(padx=10, pady=10)

log_frame = tk.Frame(root)
log_frame.pack(padx=10, pady=10)

# Control Frame
tk.Label(control_frame, text="Simulation Controls").grid(row=0, column=0, columnspan=2)

aviary = None  # Declare aviary as a global variable

def start_simulation():
    global aviary
    try:
        if aviary is None:
            # Use CustomObjectPickupAviary to start the simulation
            aviary = CustomObjectPickupAviary()
            aviary.reset()
            log_text.insert(tk.END, "Simulation started\n")
        else:
            log_text.insert(tk.END, "Simulation is already running\n")
    except Exception as e:
        log_text.insert(tk.END, f"Error starting simulation: {str(e)}\n")

def stop_simulation():
    global aviary
    try:
        if aviary is not None:
            aviary.step()
            p.disconnect(aviary.CLIENT)  # Disconnect the client
            aviary = None  # Reset the aviary instance
            log_text.insert(tk.END, "Simulation stopped\n")
        else:
            log_text.insert(tk.END, "No simulation is running\n")
    except Exception as e:
        log_text.insert(tk.END, f"Error stopping simulation: {str(e)}\n")

start_button = tk.Button(control_frame, text="Start Simulation", command=start_simulation)
start_button.grid(row=1, column=0, padx=5, pady=5)

stop_button = tk.Button(control_frame, text="Stop Simulation", command=stop_simulation)
stop_button.grid(row=1, column=1, padx=5, pady=5)

# Parameter Frame
tk.Label(parameter_frame, text="Simulation Parameters").grid(row=0, column=0, columnspan=2)

tk.Label(parameter_frame, text="Parameter 1:").grid(row=1, column=0, sticky=tk.E)
param1_entry = tk.Entry(parameter_frame)
param1_entry.grid(row=1, column=1)

tk.Label(parameter_frame, text="Parameter 2:").grid(row=2, column=0, sticky=tk.E)
param2_entry = tk.Entry(parameter_frame)
param2_entry.grid(row=2, column=1)

# Log Frame
tk.Label(log_frame, text="Simulation Logs").grid(row=0, column=0)
log_text = tk.Text(log_frame, height=10, width=50)
log_text.grid(row=1, column=0)

# Run the application
root.mainloop()
