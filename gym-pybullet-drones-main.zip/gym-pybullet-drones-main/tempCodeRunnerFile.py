
log_text = tk.Text(log_frame, height=10, width=50)
log_text.grid(row=1, column=0)
