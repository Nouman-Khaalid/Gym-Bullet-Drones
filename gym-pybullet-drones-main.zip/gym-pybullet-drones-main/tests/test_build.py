def test_imports():
    import gym_pybullet_drones
    import gym_pybullet_drones.control
    import gym_pybullet_drones.envs
    import gym_pybullet_drones.examples
    import gym_pybullet_drones.utils
